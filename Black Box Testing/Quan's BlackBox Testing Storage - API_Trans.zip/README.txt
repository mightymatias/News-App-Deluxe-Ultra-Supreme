- This is a blackbox testing for consistence of Storage.
- Require external Lib:
	+ json.org.jar
- This test is involved by four classes: API_Translator, Storage, Main (without GUI) and Article
/**This test involve API_Translator and Storage
* This test focusing on 2 main things:
* Testing case: cat, dog, apple, samsung, universe
* 1, API_Trans is working normally
*      Testing method: any of the SortByX methods.
*
*    Expectation: API_trans does return a JSONObj.
*    Evaluation: if a JSONObj is returned -> case passed.
*
* 2, Storage Function is working normally
*      Testing methods:
*    Create local storage (txt) + Load out: method's names: initializeStorage()
*    Load in: method's names: clearStorage() + updateStorage()
*    deleteArticle();
*    selectArticle; and viewAll();
*
*     Expectation:
*     2.1, A txt file is created
*     2.2, result #of Article  = #of article in the local storage.
*     2.3, adding
*     2.4, removing: perform 10 deletions in storage (9 normal + 1 preset expected failing)
*     2.5, viewing and article: view all articles/view an article (saved article)
*
*     Evaluation:
*     2.1 if a txt file is created -> local storage creation passed.
*     2.2 if #of Article  = #of article in the local storage -> load in passed
*     2.3 if previous test is passed then -> adding is passed
*     2.4.1 if after deletion the size of the arrays is reduce = to the amount of success deletions(9) -> passed
*     2.4.2 check if the selected article is really removed -> if true then passed
*     2.5.1 view all: if all articles are returned to be view successfully -> passed
*     2.5.2 single view: perform 9 + 1 expected failing test
* */

//Various changes can happen after test.