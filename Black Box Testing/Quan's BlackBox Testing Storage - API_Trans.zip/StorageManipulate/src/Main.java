/*
Last update: 22 March 2021

The main method of the project

Contributing authors: Austin Matias
 */

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void compare_in_out(Storage _db, ArrayList testArr) throws IOException {

        emptyStorage(_db);                                                                                              //State: _DBArray = null
                                                                                                                        //       txt file clear.
        try {
            for (int i = 0; i < testArr.size(); i++) {
                _db.addArticle((Article) testArr.get(i));                                                               //modify array with cat article
            }
            _db.updateStorage();                                                                                        //load array into storage

            System.out.println("DB array size :"+ _db.favoriteArray.size());
            System.out.println("TEST array size :"+ testArr.size());
            if (testArr.size() == _db.favoriteArray.size())                                                             //compare
                System.out.println("Case passed!\n");
            else
                System.out.println("Case failed!\n");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void emptyStorage(Storage _db) throws IOException {
        _db.clearStorage();
        int size = _db.favoriteArray.size();
        for (int x = size-1; x >=0 ; x--)
        {
            _db.favoriteArray.remove(x);
        }
    }

    public static void storageAndTransTest(API_Translator _trans, Storage _db) throws IOException                                           //TESTED: PASSED
    {
        /**This test involve API_Translator and Storage
         * This test focusing on 2 main things:
         * Testing case: cat, dog, apple, samsung, universe
         * 1, API_Trans is working normally
         *      Testing method: any of the SortByX methods.
         *
         *    Expectation: API_trans does return a JSONObj.
         *    Evaluation: if a JSONObj is returned -> case passed.
         *
         * 2, Storage Function is working normally
         *      Testing methods:
         *      - Create local storage (txt) + Load out: method's names: initializeStorage()
         *      - Load in: method's names: clearStorage() + updateStorage()
         *      - deleteArticle();
         *      - selectArticle; and viewAll();
         *
         *     Expectation:
         *     2.1, A txt file is created
         *     2.2, result #of Article  = #of article in the local storage.
         *     2.3, adding
         *     2.4, removing: perform 10 deletions in storage (9 normal + 1 preset expected failing)
         *     2.5, viewing and article: view all articles/view an article (saved article)
         *
         *     Evaluation:
         *     2.1 if a txt file is created -> local storage creation passed.
         *     2.2 if #of Article  = #of article in the local storage -> load in passed
         *     2.3 if previous test is passed then -> adding is passed
         *     2.4.1 if after deletion the size of the arrays is reduce = to the amount of success deletions(9) -> passed
         *     2.4.2 check if the selected article is really removed -> if true then passed
         *     2.5.1 view all: if all articles are returned to be view successfully -> passed
         *     2.5.2 single view: perform 9 + 1 expected failing test
         * */

/**********************************************************************************************************************************************************************************************/
        //1. API_trans test
        JSONObject Json_Cat = _trans.sortByKeyword("cat");                                                      // JSON of cat
        JSONObject Json_Dog = _trans.sortByKeyword("dog");                                                      // JSON of dog
        JSONObject Json_Apple =  _trans.sortByKeyword("apple");                                                 // JSON of apple
        JSONObject Json_Samsung =  _trans.sortByKeyword("samsung");                                             // JSON of samsung
        JSONObject Json_Universe =  _trans.sortByKeyword("universe");                                           // JSON of universe
        JSONObject Json_Nonexist = _trans.sortByKeyword("Ung Thu Co Tu Cung");                                  // JSON of something I know that will not be able to found


        System.out.println("\n1.0 API trans test result:");
        System.out.println("Cat case:\n "+ Json_Cat);
        System.out.println("Dog case:\n "+ Json_Dog);
        System.out.println("Apple case:\n "+ Json_Apple);
        System.out.println("Samsung case:\n "+ Json_Samsung);
        System.out.println("Universe case:\n "+ Json_Universe);
        System.out.println("Nonexist case:\n" + Json_Nonexist);                                                         //This is suppose to return 0 results

/**********************************************************************************************************************************************************************************************/
        System.out.println("\n2.1 Storage creation test");
        //2.1, Create storage
        _db.initializeStorage();                                                                                        //Create database and Load out data
        System.out.println("Take a look to the left to see if txt file is created.\n");                                 //if a txt file appear -> passed.

/**********************************************************************************************************************************************************************************************/
        ArrayList<Article> temp_cat = _trans.getArrayListOfArticlesFromJSONObject(Json_Cat);                            //Array Cat
        ArrayList<Article> temp_dog = _trans.getArrayListOfArticlesFromJSONObject(Json_Dog);                            //Array Dog
        ArrayList<Article> temp_apple = _trans.getArrayListOfArticlesFromJSONObject(Json_Apple);                        //Array Apple
        ArrayList<Article> temp_samsung = _trans.getArrayListOfArticlesFromJSONObject(Json_Samsung);                    //Array Samsung
        ArrayList<Article> temp_universe = _trans.getArrayListOfArticlesFromJSONObject(Json_Universe);                  //Array Universe
        ArrayList<Article> temp_nonexist = _trans.getArrayListOfArticlesFromJSONObject(Json_Nonexist);                  //Array Universe

        System.out.println("\n2.2-3. Load in, load out, and adding test!");
        //2.2 Load in load out test
        //load in and compare
        compare_in_out(_db, temp_cat);                                                                                  //compare cat case
        compare_in_out(_db, temp_dog);                                                                                  //compare dog case
        compare_in_out(_db, temp_apple);                                                                                //compare apple case
        compare_in_out(_db, temp_samsung);                                                                              //compare samsung case
        compare_in_out(_db, temp_universe);                                                                             //compare universe case
        compare_in_out(_db, temp_nonexist);                                                                             //compare universe case

        //2.3 Adding test
        //if the compare is passed -> adding test is also passed

/**********************************************************************************************************************************************************************************************/
        System.out.println("\n2.4 DELETION TEST!");
        //2.4 Deleting test
        emptyStorage(_db);                                                                                              //refresh storage
        for (int i = 0; i < temp_cat.size(); i++)
            _db.addArticle((Article) temp_cat.get(i));                                                                  //modify array with cat article
        for (int i = 0; i < temp_dog.size(); i++)
            _db.addArticle((Article) temp_dog.get(i));                                                                  //modify array with dog article
        for (int i = 0; i < temp_apple.size(); i++)
            _db.addArticle((Article) temp_apple.get(i));                                                                //modify array with apple article
        for (int i = 0; i < temp_samsung.size(); i++)
            _db.addArticle((Article) temp_samsung.get(i));                                                              //modify array with samsung article
        for (int i = 0; i < temp_universe.size(); i++)
            _db.addArticle((Article) temp_universe.get(i));                                                             //modify array with universe article

        _db.updateStorage();

        //So at this point there must be multiple article in _db.favorite.
        int dbSize = _db.favoriteArray.size();
        //perform 10 deletions to see if the db size is changed? if yes -> delete test passed
        for (int i = 0; i < 9; i++)
        {
            String title = _db.favoriteArray.get(i).getTitle();
            System.out.println("Test case #" + (i+1) + "\nSelected title: " + title);
            System.out.println("Perform deletion. . .");
            _db.deleteArticle(title);
            System.out.println("\nSearch for the article to see if it really removed");
            if (_db.selectArticle(title)==-1)                                                                          //check to see if the selected article is removed or not
                System.out.println("\nArticle cannot found.");
            else
                System.out.println("\nFound Article. Test Failed");
        }

        String failTitle = "This is a random string create to be tested fail";
        System.out.println("Test case #10 failed expected \nSelected title: " + failTitle);
        int db_size_after_deletion = _db.favoriteArray.size();

        _db.deleteArticle(failTitle);                                                                                   //this string is not a title therefore no deletion will be perform
        System.out.println("Databse size: " + dbSize + "\nDatabase size after deletion: " + db_size_after_deletion);
        if (dbSize == (db_size_after_deletion + 9))
            System.out.println("Deletion test passed");
        else
            System.out.println("Deletion test failed");
/**********************************************************************************************************************************************************************************************/
        System.out.println("\n2.5.1: View article test!");                                                              //using the same array of article
        System.out.println("\nView All articles");
        _db.viewArticles();

/**********************************************************************************************************************************************************************************************/
        System.out.println("\n2.5.2 View single article:");
        for (int i = 0; i < 9; i++)
        {
            String title_view = _db.favoriteArray.get(i).getTitle();
            System.out.println("Test case #"+ (i+1) +"\nSelected title: " + title_view);
            if (_db.selectArticle(title_view)!=-1)
                _db.viewSelectedArticle(_db.selectArticle(title_view));
            else
                System.out.println("Article not found. Test failed!");
        }

        String test_view = "Failed String";
        System.out.println("TEST case #10(fail expected): Selected title: " + test_view);
        if (_db.selectArticle(test_view)!=-1)
            System.out.println("This is weird. Who could wrote this article? Test not fail but result is unexpected!");
        else
            System.out.println("Article not found. Test Succeed!");

/**********************************************************************************************************************************************************************************************/
    }

    public static void main(String[] args) throws IOException, JSONException {
        API_Translator translator = new API_Translator();                                                               // one and only main API_trans
        Storage mainStorage = new Storage();                                                                            // main Storage that actual link to the local db

        storageAndTransTest(translator, mainStorage);
        //testClearStorage                                                                                              //Currently having a txt file loaded with articles

                                                    /**App Starting (Main MODEL without GUI)
        appStarted(translator, mainStorage, favorites);
                                                     */
    }

    /**App Starting*/
    public static void appStarted(API_Translator _trans, Storage _mainDB, ArrayList _fav) throws JSONException, IOException {
        System.out.println("Wellcome to the NewsApp!\n Please enter your name:");
        Scanner in = new Scanner(System.in);

        String username = in.nextLine();
        System.out.println("Hello, " + username );                                                                      //load menu opt.
        loadMenu(username);
        String options = in.nextLine();
        boolean state = true;
        while (state)
        {
            if (validSelection(options, 6) == true){
                state = false;
            } else {
                state = true;
            }
        }
        switch (Integer.parseInt(options))
        {
            case 1:
                keywords(_trans);
                System.out.println("Do you want to save this to your favorite list? (Y/N)");
                break;
            case 2:
                dom(_trans);
                break;
            case 3:
                country(_trans);
                break;
            case 4:
                category(_trans);
                break;
            case 5:
                loadLocalFavorite(_fav);
                break;
            case 6:
                exitApp(_mainDB);
            default:
                break;
        }
    }

    /**Main Menu
     * From option 1 - 4 each function return 1 Article Objs
     * option 5 is read pre-saved articles
     * option 6 is close app
     * later will be decided to add on the favorite list by user.*/
    public static void loadMenu(String username) {


        System.out.println( "1, Search for news by keywords\n" +
                            "2, Search for news by website domain\n" +
                            "3, Search for news by country\n" +
                            "4, Search for news by category\n" +
                            "5, Load " + username + "'s favorite news\n" +
                            "6, Exit."
        );

        System.out.println("Please select what you want to do.");                   //show labels for user to click on
        //NOTE: need labels from Connor
    }

    /**Selection no.1: Search by keyword*/
    public static Article keywords(API_Translator _trans) throws JSONException {
        Article retKeyArticle;
        Scanner keySc = new Scanner(System.in);
        System.out.println("\nPlease enter your keywords: ");                                                           //input box by GUI needed
        String keyword = keySc.nextLine();
        JSONObject jsonForm = _trans.sortByKeyword(keyword);                                                            //Getting Json
            if (jsonForm.getInt("totalResults") == 0)
            {                                         //zero result case
                System.out.println("Sorry, no article has been found please try again!");
                retKeyArticle = keywords(_trans);
            }
            else
            {
                ArrayList<Article> temp = _trans.getArrayListOfArticlesFromJSONObject(jsonForm);                        //store the whole json into an arrayList
                for (int i = 0; i < temp.size(); i++) {
                    String printStr = temp.get(i).toString();
                    System.out.println(i + " " + printStr);                                                             //print article with article number at the start for selection
                }
                System.out.println("Please select the article you like by entering its number (index)");
                String articleNum = keySc.nextLine();                                                                    //getting user selection of article
                retKeyArticle = _trans.getSpecificArticleFromJSON(jsonForm, Integer.parseInt(articleNum));
            }
        return retKeyArticle;
    }
    /**Selection no.2: Search by domain*/
    public static Article dom(API_Translator _trans) throws JSONException {
        Article retDomArticle;
        Scanner domSc = new Scanner(System.in);
        System.out.println("\nPlease enter your domain: ");                                                             //input box by GUI needed
        String dom = domSc.nextLine();
        JSONObject jsonForm = _trans.sortByDom(dom);
        if (jsonForm.getInt("totalResults") == 0)                                                                   //zero result case
        {
            System.out.println("Sorry, no article from given domain has been found please try again!");
            retDomArticle = dom(_trans);
        }
        else
        {
            ArrayList<Article> temp = _trans.getArrayListOfArticlesFromJSONObject(jsonForm);                            //store the whole json into an arrayList
            for (int i = 0; i < temp.size(); i++) {
                String printStr = temp.get(i).toString();
                System.out.println(i + " " + printStr);                                                                 //print article with article number at the start for selection
            }
            System.out.println("Please select the article you like by entering its number (index)");
            String articleNum = domSc.nextLine();                                                                           //getting user selection of article
            retDomArticle = _trans.getSpecificArticleFromJSON(jsonForm, Integer.parseInt(articleNum));
        }
        return retDomArticle;
    }
    /**Selection no.3: Search by country*/
    public static Article country(API_Translator _trans) {
        JSONObject jsonForm;
        Article retArticle;
        //possible country tags not yet implemented
        String countries =  "\n ae  - ar  - at  - au  - be  - bg  - br  - ca  - ch  - cn  " +
                            "\n co  - cu  - cz  - de  - eg  - fr  - gb  - gr  - hk  - hu " +
                            "\n id  - ie  - il  - in  - it  - jp  - kr  - lt  - lv  - ma  " +
                            "\n mx  - my  - ng  - nl  - no  - nz  - ph  - pl  - pt  - ro  " +
                            "\n rs  - ru  - sa  - se  - sg  - si  - sk - th  - tr  - tw  " +
                            "\n ua  - us  - ve  - za";                                          //54 countries
        System.out.println("\nList of available country: " + countries);
        // maybe needed this much labels for all of these countries - Connor please explain your GUI so I can help you a hand on building these amount of labels
        Scanner countrySc = new Scanner(System.in);
        System.out.println("\nPlease enter the country you'd like!");                           //input box by GUI needed
        String country = countrySc.nextLine();
        if (countries.contains(country) == false)                                               //valid country fail check
        {
            System.out.println("Your input is invalid!\nPlease try again!");
            retArticle = country(_trans);
        }
        else {                                                                                  //valid input accepted
            jsonForm = _trans.sortByCountry(country);
            ArrayList<Article> temp = _trans.getArrayListOfArticlesFromJSONObject(jsonForm);    //store the whole json into an arrayList
            for (int i = 0; i < temp.size(); i++)
            {
                String printStr = temp.get(i).toString();
                System.out.println(i + " " + printStr);                                          //print article with article number at the start
            }
            System.out.println("Please select the article you like by entering its number (index)");
            String articleNum = countrySc.nextLine();                                                //getting user selection of article
            retArticle = _trans.getSpecificArticleFromJSON(jsonForm, Integer.parseInt(articleNum));
        }
        return retArticle;
    }
    /**Selection no.4: Search by category*/
    public static Article category(API_Translator _trans) {
        JSONObject cateJsonForm;
        Article retCateArticle;
        //possible category tags not yet implemented
        String categories = "business - entertainment - general - health - science - sports - technology";
        Scanner cateSc = new Scanner(System.in);
        System.out.println("\nPlease enter the category you'd like!");                             //input box by GUI needed
        String category = cateSc.nextLine();
        if (categories.contains(category) == false)                                                //valid category fail check
        {
            System.out.println("Your input is invalid!\nPlease try again!");
            retCateArticle = country(_trans);
        }
        else {                                                                                      //valid input accepted
            cateJsonForm = _trans.sortByCategory(category);
            ArrayList<Article> temp = _trans.getArrayListOfArticlesFromJSONObject(cateJsonForm);    //store the whole json into an arrayList
            for (int i = 0; i < temp.size(); i++)
            {
                String printStr = temp.get(i).toString();
                System.out.println(i + " " + printStr);                                             //print article with article number at the start for selection
            }
            System.out.println("Please select the article you like by entering its number (index)");
            String articleNum = cateSc.nextLine();                                                      //getting user selection of article
            retCateArticle = _trans.getSpecificArticleFromJSON(cateJsonForm, Integer.parseInt(articleNum));
        }
        return retCateArticle;
    }

    /**Selection no.5: Load pre-saved user's favorite article*/
    public static void loadLocalFavorite(ArrayList _fav) {
        /**I need Connor GUI to create a view for each article.
         * also we can go to next article by a forward/backward button*/
        System.out.println("\t\tUser favorite article");
        for (int i = 0; i < _fav.size(); i++)
        {
            System.out.println("Article #" + i + ":\n" + _fav.get(i));
        }
    }

    /**Selection no.6: Exit (Update local storage and close app)*/
    public static void exitApp(Storage _db) throws IOException {
        _db.updateStorage();
        System.out.println("Thank you for choosing NewsApp\nSee you later!");
        System.exit(0);
    }

    /**Support methods*/
    public static boolean validSelection(String options, int condition)
    {

        if (Integer.parseInt(options) > condition)
        {
            System.out.println("Invalid selection. Please try again");
            return false;
        }
        else
            return true;
    } //Main model's methods without GUI
}

