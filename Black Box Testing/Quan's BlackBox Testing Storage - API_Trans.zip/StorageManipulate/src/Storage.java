import java.io.*;
import java.lang.*;
import java.util.ArrayList;
import java.util.*;
import java.util.Arrays;
import java.util.Scanner;
import java.lang.StringBuilder;
import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;

/**         HOW DOES THIS CLASS WORK? (BASIC)
 *          First: Having an ArrayList of favorite Article and Check for existent of txt file (if not exist then create) (if exist then load data into an arraylist)
 *          Second: (optional) to add an article to favorite                    use method  addArticle (Article _article)
 *          Third:  (optional) to delete an article from the List               use method  deleteArticle (String _title)
 *          Fourth: (optional) to select an article from the List               use method  selectArticle (String _title)
 */

public class Storage {

    private String filePath = "FavoriteArticles.txt";
    protected ArrayList<Article> favoriteArray = new ArrayList<>();

    public Storage() {

    }

    /**
     * To be used on program load to ensure that the favorite article file exists, and to create it if it does not,
     * then to load the array of favorited articles from system storage.
     */

    /**Initialization Phase*/
    /**
     * Create file and load file data into array
     */
    protected void initializeStorage() throws IOException {
        ensureFileExistence();
        loadArray();
    }

    /**
     * Check file existence if not -> create the file
     */
    private boolean ensureFileExistence() {
        //create the file object
        File favoriteArticles = new File(filePath);
        //check to see if the file exists, if not, create it
        try {
            if (!favoriteArticles.exists()) {
                favoriteArticles.createNewFile();
            }
        } catch (Exception e) {
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
        //return statement should always return true
        return favoriteArticles.exists();
    }

    //Load file data to array
    private void loadArray() {
        try {
            Scanner input = new Scanner(new File(filePath));
            //setting variables to be assigned to object
            while (input.hasNextLine()) {
                String title = input.nextLine();
                String author = input.nextLine();
                String description = input.nextLine();
                String url = input.nextLine();
                String urlToImage = input.nextLine();
                String publishedAt = input.nextLine();
                input.nextLine();

                Article newArt = new Article(title,author,description,url,urlToImage,publishedAt);
                addArticle(newArt);
            }

        } catch (Exception e) {
        }
        //System.out.println(favoriteArray);
    }


    /**Modification Phase*/
    /**Clear storage*/
    public void clearStorage() throws IOException {
            FileWriter fw = new FileWriter("FavoriteArticles.txt", false);
            fw.write("");
            fw.close();
    }


    /** Delete from DB
     /** @paramm _title might be getting from Article.getTitle
     * Using hashmap to search for that article index in the array
     * After that remove it from running Array before update storage*/
    public void deleteArticle (String _title) throws IOException {
        /**String gonna be the title as key, Integer gonna be the index of that title in array.*/
        /** def loadfactor 0.7f*/
        Map<String, Integer> articleIndex = new HashMap<String, Integer>();

        for (int i = 0; i < favoriteArray.size(); i++) {                                                                // looping any indexing title of article in favoriteArray
            String currentIndexTitle = favoriteArray.get(i).getTitle();
            int indexValue = i;
            articleIndex.put(currentIndexTitle, indexValue);                                                            // put current pair ("title", index) into the map
        }

        if (articleIndex.containsKey(_title)) {                                                                         // checking existence of article
            int getIndex = articleIndex.get(_title);                                                                    // getting the index from given title
            favoriteArray.remove(getIndex);
            System.out.println("Article has been removed from your favorite list.");
        }
        else
        {
            System.out.println("The article you are looking for is not exist!");
        }
        updateStorage();

    }

    /** Clear the current txt file and reload into it with new list from the arraylist*/
    public void updateStorage() throws IOException {
        clearStorage();
        FileWriter textLoader = new FileWriter("FavoriteArticles.txt", true);
        for (int i  = 0; i < favoriteArray.size(); i++) {                                                               // toString each article in the favoriteArray then add it into the DB
            String theArticle = favoriteArray.get(i).toString();
            textLoader.append(theArticle);
        }
        textLoader.close();
    }



    /** Add a new article to theDataArray (line 11) but this time require an Article Obj*/
    public void addArticle(Article _article)
    {
        if (selectArticle(_article.getTitle()) != -1)
            System.out.println("Trying to add article but it is already exist! Skip forward");
        else
        favoriteArray.add(_article);
    }

    /**Support method*/
    /**Select article from storage
     * Require title name String
     * Return index of the article*/
    public int selectArticle(String _title) {
        /**String gonna be the title as key, Integer gonna be the index of that title in array.
        * def loadfactor 0.7f*/
        int getIndex = -1;
        Map<String, Integer> articleIndex = new HashMap<String, Integer>();

        for (int i = 0; i < favoriteArray.size(); i++) {                                                                //looping any indexing title of article in favoriteArray
            String currentIndexTitle = favoriteArray.get(i).getTitle();
            articleIndex.put(currentIndexTitle, i);                                                                     //put current pair ("title", index) into the map
        }
        if (articleIndex.containsKey(_title)) {                                                                         //checking existence of article
            getIndex= articleIndex.get(_title);
            return getIndex;                                                                                            //getting the index from given title
        }
        else
        {
            return getIndex;
        }

    }

    /**View selected article
     * #@param index get index of the article
     * return print the article*/
    public void viewSelectedArticle(int index)
    {
        System.out.println(favoriteArray.get(index).toString());
    }

    /**View saved favorite articles*/
    public void viewArticles() {
        for (int i = 0; i < favoriteArray.size(); i++)
        {
            System.out.println("Article #" + i + ":\n" + favoriteArray.get(i));
        }
    }

}
